﻿using APIFORD.Util;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace APIFORD.Data.DTOS.Notifications;

public class ReadNotificationDTO
{
    public string Id { get; set; }
    public NotificationTypes Tipo { get; set; }
    public string Titulo { get; set; }
    public string? Subtitulo { get; set; }
    // Model/NotificacaoEvento.cs — adiciona a property
    public int? LinhagemIdReferenciado { get; set; }
    public object Mensagem { get; set; }
    public bool Lido { get; set; }
    public bool Excluido { get; set; }
    public DateTime DataCriacao { get; set; }
    public DateTime DataLeitura { get; set; }

}

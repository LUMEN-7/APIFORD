﻿using APIFORD.Model.Annotation;
using System.ComponentModel.DataAnnotations;

namespace APIFORD.Data.DTOS.Annotations;

/// <summary>Request (aninhado) — um bloco dentro de uma substituição em lote (AtualizarBlocosDTO).</summary>
public class BlocoDTO : IValidatableObject
{
    public string? Id { get; set; } // null = bloco novo; preenchido = bloco existente sendo mantido/reordenado

    [EnumDataType(typeof(TipoBloco), ErrorMessage = "Tipo de bloco inválido.")]
    public TipoBloco Tipo { get; set; }

    public string? Texto { get; set; }
    public int? LinhagemIdReferenciado { get; set; }
    public int? ComparacaoIdReferenciada { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (Tipo == TipoBloco.CardCarro && LinhagemIdReferenciado == null)
            yield return new ValidationResult("LinhagemIdReferenciado é obrigatório para blocos do tipo CardCarro.", new[] { nameof(LinhagemIdReferenciado) });

        if (Tipo == TipoBloco.CardComparacao && ComparacaoIdReferenciada == null)
            yield return new ValidationResult("ComparacaoIdReferenciada é obrigatório para blocos do tipo CardComparacao.", new[] { nameof(ComparacaoIdReferenciada) });
    }
}